#include "pch.h"
#include"myForm.h"
#include "Player.h"
#include "Game.h"
#include "Location.h"
#include "Player.h"
#include "Board.h"
#include "Board.cpp"

using namespace System;
using namespace System::Windows::Forms;
[STAThreadAttribute]
void Main(array < String^>^ args) {
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	NineMMorris::MyForm form;
	Application::Run(% form);
}

