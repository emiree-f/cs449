#pragma once
#include <iostream> //remove when GUI added
#include "Game.h"
#include "Location.h"
#include "Player.h"
#include "Board.h"
#include "Board.cpp"

namespace NineMMorris {
	std::string placeLocationChoice;
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}
//#pragma endregion
	private: System::Void Bob_Click(System::Object^ sender, System::EventArgs^ e)
	{
		String^ firstTurn = Player1->Text;
		bool turn1st = (firstTurn == "black") ? true : false; //remove when GUI added
		String^ location = Location->Text;
		MessageBox::Show("Piece " + firstTurn + "' will go first");
		MessageBox::Show(firstTurn + " Where would you like to place your pice? - Enter in Location box");
	}

	private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) 
	{
	Close();
	}

	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {

		String^ Placement = Location->Text;

	}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	protected:
	private: System::Windows::Forms::Button^ a7;
	private: System::Windows::Forms::Button^ d7;
	private: System::Windows::Forms::Button^ g7;
	private: System::Windows::Forms::Button^ b6;
	private: System::Windows::Forms::Button^ d6;
	private: System::Windows::Forms::Button^ f6;
	private: System::Windows::Forms::Button^ c5;
	private: System::Windows::Forms::Button^ d5;
	private: System::Windows::Forms::Button^ e5;
	private: System::Windows::Forms::Button^ c4;
	private: System::Windows::Forms::Button^ c3;
	private: System::Windows::Forms::Button^ d3;
	private: System::Windows::Forms::Button^ e3;
	private: System::Windows::Forms::Button^ e4;
	private: System::Windows::Forms::Button^ f4;
	private: System::Windows::Forms::Button^ a1;
	private: System::Windows::Forms::Button^ d2;
	private: System::Windows::Forms::Button^ g1;
	private: System::Windows::Forms::Button^ b4;
	private: System::Windows::Forms::Button^ g4;
	private: System::Windows::Forms::Button^ a4;
	private: System::Windows::Forms::Button^ b2;
	private: System::Windows::Forms::Button^ f2;
	private: System::Windows::Forms::TextBox^ Player1;
	private: System::Windows::Forms::Label^ label1;


	private: System::Windows::Forms::Button^ Bob;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::TextBox^ Location;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->a7 = (gcnew System::Windows::Forms::Button());
			this->d7 = (gcnew System::Windows::Forms::Button());
			this->g7 = (gcnew System::Windows::Forms::Button());
			this->b6 = (gcnew System::Windows::Forms::Button());
			this->d6 = (gcnew System::Windows::Forms::Button());
			this->f6 = (gcnew System::Windows::Forms::Button());
			this->c5 = (gcnew System::Windows::Forms::Button());
			this->d5 = (gcnew System::Windows::Forms::Button());
			this->e5 = (gcnew System::Windows::Forms::Button());
			this->c4 = (gcnew System::Windows::Forms::Button());
			this->c3 = (gcnew System::Windows::Forms::Button());
			this->d3 = (gcnew System::Windows::Forms::Button());
			this->e3 = (gcnew System::Windows::Forms::Button());
			this->e4 = (gcnew System::Windows::Forms::Button());
			this->f4 = (gcnew System::Windows::Forms::Button());
			this->a1 = (gcnew System::Windows::Forms::Button());
			this->d2 = (gcnew System::Windows::Forms::Button());
			this->g1 = (gcnew System::Windows::Forms::Button());
			this->b4 = (gcnew System::Windows::Forms::Button());
			this->g4 = (gcnew System::Windows::Forms::Button());
			this->a4 = (gcnew System::Windows::Forms::Button());
			this->b2 = (gcnew System::Windows::Forms::Button());
			this->f2 = (gcnew System::Windows::Forms::Button());
			this->Player1 = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->Bob = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->Location = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// a7
			// 
			this->a7->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->a7->ForeColor = System::Drawing::Color::Blue;
			this->a7->Location = System::Drawing::Point(16, 44);
			this->a7->Margin = System::Windows::Forms::Padding(4);
			this->a7->Name = L"a7";
			this->a7->Size = System::Drawing::Size(88, 69);
			this->a7->TabIndex = 0;
			this->a7->Text = L"a7";
			this->a7->UseVisualStyleBackColor = false;
			// 
			// d7
			// 
			this->d7->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->d7->ForeColor = System::Drawing::Color::Blue;
			this->d7->Location = System::Drawing::Point(340, 44);
			this->d7->Margin = System::Windows::Forms::Padding(4);
			this->d7->Name = L"d7";
			this->d7->Size = System::Drawing::Size(88, 69);
			this->d7->TabIndex = 1;
			this->d7->Text = L"d7";
			this->d7->UseVisualStyleBackColor = false;
			// 
			// g7
			// 
			this->g7->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->g7->ForeColor = System::Drawing::Color::Blue;
			this->g7->Location = System::Drawing::Point(667, 44);
			this->g7->Margin = System::Windows::Forms::Padding(4);
			this->g7->Name = L"g7";
			this->g7->Size = System::Drawing::Size(88, 69);
			this->g7->TabIndex = 2;
			this->g7->Text = L"g7";
			this->g7->UseVisualStyleBackColor = false;
			// 
			// b6
			// 
			this->b6->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->b6->ForeColor = System::Drawing::Color::Blue;
			this->b6->Location = System::Drawing::Point(129, 155);
			this->b6->Margin = System::Windows::Forms::Padding(4);
			this->b6->Name = L"b6";
			this->b6->Size = System::Drawing::Size(88, 69);
			this->b6->TabIndex = 3;
			this->b6->Text = L"b6";
			this->b6->UseVisualStyleBackColor = false;
			this->b6->Click += gcnew System::EventHandler(this, &MyForm::b6_Click);
			// 
			// d6
			// 
			this->d6->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->d6->ForeColor = System::Drawing::Color::Blue;
			this->d6->Location = System::Drawing::Point(340, 155);
			this->d6->Margin = System::Windows::Forms::Padding(4);
			this->d6->Name = L"d6";
			this->d6->Size = System::Drawing::Size(88, 69);
			this->d6->TabIndex = 4;
			this->d6->Text = L"d6";
			this->d6->UseVisualStyleBackColor = false;
			// 
			// f6
			// 
			this->f6->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->f6->ForeColor = System::Drawing::Color::Blue;
			this->f6->Location = System::Drawing::Point(549, 155);
			this->f6->Margin = System::Windows::Forms::Padding(4);
			this->f6->Name = L"f6";
			this->f6->Size = System::Drawing::Size(88, 69);
			this->f6->TabIndex = 5;
			this->f6->Text = L"f6";
			this->f6->UseVisualStyleBackColor = false;
			// 
			// c5
			// 
			this->c5->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->c5->ForeColor = System::Drawing::Color::Blue;
			this->c5->Location = System::Drawing::Point(244, 266);
			this->c5->Margin = System::Windows::Forms::Padding(4);
			this->c5->Name = L"c5";
			this->c5->Size = System::Drawing::Size(88, 69);
			this->c5->TabIndex = 6;
			this->c5->Text = L"c5";
			this->c5->UseVisualStyleBackColor = false;
			// 
			// d5
			// 
			this->d5->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->d5->ForeColor = System::Drawing::Color::Blue;
			this->d5->Location = System::Drawing::Point(340, 266);
			this->d5->Margin = System::Windows::Forms::Padding(4);
			this->d5->Name = L"d5";
			this->d5->Size = System::Drawing::Size(88, 69);
			this->d5->TabIndex = 7;
			this->d5->Text = L"d5";
			this->d5->UseVisualStyleBackColor = false;
			// 
			// e5
			// 
			this->e5->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->e5->ForeColor = System::Drawing::Color::Blue;
			this->e5->Location = System::Drawing::Point(436, 266);
			this->e5->Margin = System::Windows::Forms::Padding(4);
			this->e5->Name = L"e5";
			this->e5->Size = System::Drawing::Size(88, 69);
			this->e5->TabIndex = 8;
			this->e5->Text = L"e5";
			this->e5->UseVisualStyleBackColor = false;
			// 
			// c4
			// 
			this->c4->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->c4->ForeColor = System::Drawing::Color::Blue;
			this->c4->Location = System::Drawing::Point(244, 364);
			this->c4->Margin = System::Windows::Forms::Padding(4);
			this->c4->Name = L"c4";
			this->c4->Size = System::Drawing::Size(88, 69);
			this->c4->TabIndex = 9;
			this->c4->Text = L"c4";
			this->c4->UseVisualStyleBackColor = false;
			// 
			// c3
			// 
			this->c3->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->c3->ForeColor = System::Drawing::Color::Blue;
			this->c3->Location = System::Drawing::Point(244, 462);
			this->c3->Margin = System::Windows::Forms::Padding(4);
			this->c3->Name = L"c3";
			this->c3->Size = System::Drawing::Size(88, 69);
			this->c3->TabIndex = 10;
			this->c3->Text = L"c3";
			this->c3->UseVisualStyleBackColor = false;
			// 
			// d3
			// 
			this->d3->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->d3->ForeColor = System::Drawing::Color::Blue;
			this->d3->Location = System::Drawing::Point(340, 462);
			this->d3->Margin = System::Windows::Forms::Padding(4);
			this->d3->Name = L"d3";
			this->d3->Size = System::Drawing::Size(88, 69);
			this->d3->TabIndex = 11;
			this->d3->Text = L"d3";
			this->d3->UseVisualStyleBackColor = false;
			// 
			// e3
			// 
			this->e3->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->e3->ForeColor = System::Drawing::Color::Blue;
			this->e3->Location = System::Drawing::Point(436, 462);
			this->e3->Margin = System::Windows::Forms::Padding(4);
			this->e3->Name = L"e3";
			this->e3->Size = System::Drawing::Size(88, 69);
			this->e3->TabIndex = 12;
			this->e3->Text = L"e3";
			this->e3->UseVisualStyleBackColor = false;
			// 
			// e4
			// 
			this->e4->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->e4->ForeColor = System::Drawing::Color::Blue;
			this->e4->Location = System::Drawing::Point(436, 364);
			this->e4->Margin = System::Windows::Forms::Padding(4);
			this->e4->Name = L"e4";
			this->e4->Size = System::Drawing::Size(88, 69);
			this->e4->TabIndex = 13;
			this->e4->Text = L"e4";
			this->e4->UseVisualStyleBackColor = false;
			// 
			// f4
			// 
			this->f4->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->f4->ForeColor = System::Drawing::Color::Blue;
			this->f4->Location = System::Drawing::Point(549, 364);
			this->f4->Margin = System::Windows::Forms::Padding(4);
			this->f4->Name = L"f4";
			this->f4->Size = System::Drawing::Size(88, 69);
			this->f4->TabIndex = 14;
			this->f4->Text = L"f4";
			this->f4->UseVisualStyleBackColor = false;
			// 
			// a1
			// 
			this->a1->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->a1->ForeColor = System::Drawing::Color::Blue;
			this->a1->Location = System::Drawing::Point(16, 704);
			this->a1->Margin = System::Windows::Forms::Padding(4);
			this->a1->Name = L"a1";
			this->a1->Size = System::Drawing::Size(88, 69);
			this->a1->TabIndex = 15;
			this->a1->Text = L"a1";
			this->a1->UseVisualStyleBackColor = false;
			// 
			// d2
			// 
			this->d2->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->d2->ForeColor = System::Drawing::Color::Blue;
			this->d2->Location = System::Drawing::Point(340, 578);
			this->d2->Margin = System::Windows::Forms::Padding(4);
			this->d2->Name = L"d2";
			this->d2->Size = System::Drawing::Size(88, 69);
			this->d2->TabIndex = 16;
			this->d2->Text = L"d2";
			this->d2->UseVisualStyleBackColor = false;
			// 
			// g1
			// 
			this->g1->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->g1->ForeColor = System::Drawing::Color::Blue;
			this->g1->Location = System::Drawing::Point(667, 704);
			this->g1->Margin = System::Windows::Forms::Padding(4);
			this->g1->Name = L"g1";
			this->g1->Size = System::Drawing::Size(88, 69);
			this->g1->TabIndex = 17;
			this->g1->Text = L"g1";
			this->g1->UseVisualStyleBackColor = false;
			// 
			// b4
			// 
			this->b4->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->b4->ForeColor = System::Drawing::Color::Blue;
			this->b4->Location = System::Drawing::Point(129, 364);
			this->b4->Margin = System::Windows::Forms::Padding(4);
			this->b4->Name = L"b4";
			this->b4->Size = System::Drawing::Size(88, 69);
			this->b4->TabIndex = 18;
			this->b4->Text = L"b4";
			this->b4->UseVisualStyleBackColor = false;
			// 
			// g4
			// 
			this->g4->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->g4->ForeColor = System::Drawing::Color::Blue;
			this->g4->Location = System::Drawing::Point(667, 364);
			this->g4->Margin = System::Windows::Forms::Padding(4);
			this->g4->Name = L"g4";
			this->g4->Size = System::Drawing::Size(88, 69);
			this->g4->TabIndex = 19;
			this->g4->Text = L"g4";
			this->g4->UseVisualStyleBackColor = false;
			// 
			// a4
			// 
			this->a4->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->a4->ForeColor = System::Drawing::Color::Blue;
			this->a4->Location = System::Drawing::Point(16, 364);
			this->a4->Margin = System::Windows::Forms::Padding(4);
			this->a4->Name = L"a4";
			this->a4->Size = System::Drawing::Size(88, 69);
			this->a4->TabIndex = 20;
			this->a4->Text = L"a4";
			this->a4->UseVisualStyleBackColor = false;
			// 
			// b2
			// 
			this->b2->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->b2->ForeColor = System::Drawing::Color::Blue;
			this->b2->Location = System::Drawing::Point(129, 578);
			this->b2->Margin = System::Windows::Forms::Padding(4);
			this->b2->Name = L"b2";
			this->b2->Size = System::Drawing::Size(88, 69);
			this->b2->TabIndex = 21;
			this->b2->Text = L"b2";
			this->b2->UseVisualStyleBackColor = false;
			// 
			// f2
			// 
			this->f2->BackColor = System::Drawing::SystemColors::AppWorkspace;
			this->f2->ForeColor = System::Drawing::Color::Blue;
			this->f2->Location = System::Drawing::Point(549, 578);
			this->f2->Margin = System::Windows::Forms::Padding(4);
			this->f2->Name = L"f2";
			this->f2->Size = System::Drawing::Size(88, 69);
			this->f2->TabIndex = 22;
			this->f2->Text = L"f2";
			this->f2->UseVisualStyleBackColor = false;
			// 
			// Player1
			// 
			this->Player1->Location = System::Drawing::Point(869, 80);
			this->Player1->Name = L"Player1";
			this->Player1->Size = System::Drawing::Size(160, 22);
			this->Player1->TabIndex = 23;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(843, 60);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(192, 17);
			this->label1->TabIndex = 24;
			this->label1->Text = L"Enter first turn, black or white";
			// 
			// Bob
			// 
			this->Bob->Location = System::Drawing::Point(908, 108);
			this->Bob->Name = L"Bob";
			this->Bob->Size = System::Drawing::Size(57, 34);
			this->Bob->TabIndex = 27;
			this->Bob->Text = L"Enter";
			this->Bob->UseVisualStyleBackColor = true;
			this->Bob->EnabledChanged += gcnew System::EventHandler(this, &MyForm::Bob_Click);
			this->Bob->Click += gcnew System::EventHandler(this, &MyForm::Bob_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(894, 35);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(97, 22);
			this->button2->TabIndex = 28;
			this->button2->Text = L"Exit Game";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(781, 255);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 44);
			this->button1->TabIndex = 29;
			this->button1->Text = L"Enter2";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(778, 207);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(62, 17);
			this->label2->TabIndex = 30;
			this->label2->Text = L"Location";
			// 
			// Location
			// 
			this->Location->Location = System::Drawing::Point(762, 227);
			this->Location->Name = L"Location";
			this->Location->Size = System::Drawing::Size(100, 22);
			this->Location->TabIndex = 31;
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(1204, 743);
			this->Controls->Add(this->Location);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->Bob);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->Player1);
			this->Controls->Add(this->f2);
			this->Controls->Add(this->b2);
			this->Controls->Add(this->a4);
			this->Controls->Add(this->g4);
			this->Controls->Add(this->b4);
			this->Controls->Add(this->g1);
			this->Controls->Add(this->d2);
			this->Controls->Add(this->a1);
			this->Controls->Add(this->f4);
			this->Controls->Add(this->e4);
			this->Controls->Add(this->e3);
			this->Controls->Add(this->d3);
			this->Controls->Add(this->c3);
			this->Controls->Add(this->c4);
			this->Controls->Add(this->e5);
			this->Controls->Add(this->d5);
			this->Controls->Add(this->c5);
			this->Controls->Add(this->f6);
			this->Controls->Add(this->d6);
			this->Controls->Add(this->b6);
			this->Controls->Add(this->g7);
			this->Controls->Add(this->d7);
			this->Controls->Add(this->a7);
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		void turn() {

		}


	private: System::Void b6_Click(System::Object^ sender, System::EventArgs^ e) {
	}

	private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
	}

		  
};
}
